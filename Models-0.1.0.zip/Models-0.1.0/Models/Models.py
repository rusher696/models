import csv, os, numpy as np
def new_h(path, headers):
    with open(path, "w", newline="") as f:
        f.write(",".join(headers))
    with open(path, "r", newline="") as f:
        return f.read()  
class CModel:
    def __init__(self, path="model.csv", headers=["experiment", "result"]):
        self.memory = []
        self.headers = headers
        self.file = path
        if not os.path.exists(self.file):
            new_h(path, headers)
    def addrow(self, headers):
        with open(self.file, "a") as f:
            Nonerow = [None for _ in range(len(self.headers))]
            f.write("\n"+ (",".join(headers) if len(headers) == len(self.headers) else ",".join(str(x) for x in Nonerow)))
    def read_csv(self, f):
        result = []
        with open(f, "r") as fi:
            for row in fi:
                result.append(row)
        return result
    def clean(self, headers):
        cleaned = []
        for header in headers:
            cleaned.append(header.replace("\n", "").replace("\ufeff", ""))
        return cleaned
        
class Tensor:
    def __init__(self, data):
        self.data = np.array(data, dtype=np.float32)
        self.grad = np.zeros_like(self.data)
    def __add__(self, other):
        return Tensor(self.data + other.data)
    def __matmul__(self, other):
        return Tensor(np.dot(self.data, other.data))
    def relu(self):
        return Tensor(np.maximum(0, self.data))
    def backward(self, grad):
        self.grad += grad
class Dense:
    def __init__(self, input_size, output_size):
        self.weights = Tensor(np.random.randn(input_size, output_size) / 10)
        self.bias = Tensor(np.zeros((1, output_size)))
    def __call__(self, x):
        self.input = x
        self.output = (x @ self.weights) + self.bias
        return self.output
    def backward(self, grad_output, lr=0.01):
        self.weights.grad = self.input.data.T @ grad_output
        self.bias.grad = np.sum(grad_output, axis=0, keepdims=True)
        grad_input = grad_output @ self.weights.data.T
        self.weights.data -= lr * self.weights.grad
        self.bias.data -= lr * self.bias.grad
        return grad_input
def mse_loss(pred, target):
    loss = np.mean((pred.data - target.data) ** 2)
    grad = 2 * (pred.data - target.data) / target.data.size
    return loss, grad
class NPModel:
    def __init__(self, input_size, hidden_size, output_size):
        self.dense1 = Dense(input_size, hidden_size)
        self.dense2 = Dense(hidden_size, output_size)
    def forward(self, x):
        x = self.dense1(x).relu()
        x = self.dense2(x)
        return x
    def train(self, x, y, epochs=100, lr=0.01, prints=20):
        delay = epochs // prints if prints != 0 else 1e20
        for epoch in range(epochs):
            out1 = self.dense1(x).relu()
            out2 = self.dense2(out1)
            loss, grad = mse_loss(out2, y)
            grad2 = self.dense2.backward(grad, lr)
            relu_grad = grad2 * (out1.data > 0).astype(np.float32)
            _ = self.dense1.backward(relu_grad, lr)
            if epoch % delay == 0:
                print(f"Epoch {epoch}— loss: {loss:.6f}")
                                       